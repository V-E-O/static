#define PEERID_PREFIX             "-TR2770-"
#define USERAGENT_PREFIX          "2.77"
#define SVN_REVISION              "14734"
#define SVN_REVISION_NUM          14734
#define SHORT_VERSION_STRING      "2.77"
#define LONG_VERSION_STRING       "2.77 (14734)"
#define VERSION_STRING_INFOPLIST  2.77
#define MAJOR_VERSION             2
#define MINOR_VERSION             77
#define TR_STABLE_RELEASE         1
